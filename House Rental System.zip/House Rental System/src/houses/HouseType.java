//Student name:Mallak Nabeel Abunimeh
//Student ID:201903622

package houses;

public class HouseType {

	private int typeId;
	private String description;
	private double housePrice;
	
	public HouseType(int typeId, String description, double housePrice) {
		this.setTypeId(typeId);
		this.setDescription(description);
		this.setHousePrice(housePrice);
	}

	public int getTypeId() {
		return typeId;
	}
	
	public void setTypeId(int typeId) {
		this.typeId = typeId;
	}
	
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	public double getHousePrice() {
		return housePrice;
	}
	
	public void setHousePrice(double housePrice) {
		this.housePrice = housePrice;
	}

	@Override
	public String toString() {
		return this.getDescription()+" "+this.getHousePrice();
	}	
	
}//end of HouseType class
