//Student name:Mallak Nabeel Abunimeh
//Student ID:201903622

package houses;

public class House {

	private int houseNo;
	private String address;
	private boolean isAvailabile;
	private HouseType type;

	public House(int houseNo, String address, boolean iSa, HouseType ht2) {
		this.setHouseNo(houseNo);
		this.setAddress(address);
		this.setAvailabile(iSa);
		this.setType(ht2);
	}

	public int getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(int houseNo) {
		this.houseNo = houseNo;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public boolean isAvailabile() {
		return isAvailabile;
	}

	public void setAvailabile(boolean isAvailabile) {
		this.isAvailabile = isAvailabile;
	}
	

    public HouseType getType() {
         return type;
    }
	
	public void setType(HouseType type) {
	       this.type = type;
	}


	@Override
	public String toString() {
		return this.getHouseNo()+" "+this.getAddress()+" "+this.getType();
	}

}//end of House class
