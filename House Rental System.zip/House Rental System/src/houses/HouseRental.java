//Student name:Mallak Nabeel Abunimeh
//Student ID:201903622

package houses;
import people.*;
import payment.*;
import date.*;

public class HouseRental {

	private Tenant tenant;
	private House house;
	private Date rentalStartDate;
	private Date rentalEndDate;
	private double deposit;
	private Invoice invoice;
	
	public HouseRental(Tenant tenant, House house, Date rentalStartDate, Date rentalEndDate, double deposit,
			Invoice invoice) {
		this.setTenant(tenant);
		this.setHouse(house);
		this.setRentalStartDate(rentalStartDate);
		this.setRentalEndDate(rentalEndDate);
		this.setDeposit(deposit);
		this.setInvoice(invoice);
	}
	

	public Tenant getTenant() {
		return tenant;
	}

	public void setTenant(Tenant tenant) {
		this.tenant = tenant;
	}

	public House getHouse() {
		return house;
	}

	public void setHouse(House house) {
		this.house = house;
	}

	public Date getRentalStartDate() {
		return rentalStartDate;
	}
	
	public void setRentalStartDate(Date rentalStartDate) {
		this.rentalStartDate = rentalStartDate;
	}
	
	public Date getRentalEndDate() {
		return rentalEndDate;
	}
	
	public void setRentalEndDate(Date rentalEndDate) {
		this.rentalEndDate = rentalEndDate;
	}
	
	public double getDeposit() {
		return deposit;
	}
	
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public Invoice getInvoice() {
		return invoice;
	}
	
	public void setInvoice(Invoice invoice) {
		this.invoice = invoice;
	}

	@Override
	public String toString() {
		return this.getTenant()+" "+ this.getHouse()+" "+this.getDeposit()+this.getRentalStartDate();
	}
	
}//end of HouseRental class
