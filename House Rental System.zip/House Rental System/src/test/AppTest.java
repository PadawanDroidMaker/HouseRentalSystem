//Student name:Mallak Nabeel Abunimeh
//Student ID:201903622
	    
package test;
import people.*;
import payment.*;
import houses.*;
import oomRealState.*;

import java.util.ArrayList;

public class AppTest {

	public static void main(String[] args) {

		//Creating house 3 house types
		HouseType ht1 = new HouseType(1,"single bedroom",6000);
		HouseType ht2 = new HouseType(2,"2 bedroom ",7000);
		HouseType ht3 = new HouseType(3,"3 bedroom ",8000);

		//Creating 3 different houses
		House h1 = new House(21,"AlSadd street ",true,ht1);
		House h2 = new House(22,"Bin Mahmoud street",true,ht2);
		House h3 = new House(23,"Lusail street",true,ht3);

		//Testing oomrealstate
		OOMRealState om = new OOMRealState();

		//Adding houses 
		om.addHouse(h1);
		om.addHouse(h2);
		om.addHouse(h3);

		//finding houses by id number
		om.findHouse(21);
		om.findHouse(22);
		om.findHouse(23);

		//deleting the 3rd house by 
		om.deleteHouse(23);

		//Getting all the available houses
		ArrayList<House> aah = om.getHouseByAvailability(); //aah means (all availabile houses)

		System.out.println("All available houses are : ");

		for(House h : aah) {
			System.out.println(h);
		}

	}
}
